import numpy as np
import cv2
import pypot.dynamixel
from simple_pid import PID
from copy import deepcopy
from daytime import time
from image_processing import next_color, coord_is_in_left, coord_is_in_right, coord_is_in_center


def process_frame_rgb(frame, dico):
    if dico["COMPUTER_USED"]:
        full_frame = deepcopy(frame)

    # frame = frame[0:height, int(width/2)-5:int(width/2)+5]
    if not dico["COMPUTER_USED"]:
        frame = frame[dico["top_band"]:dico["bot_band"], 0:dico["width"]]

    # Mask and output for color to be followed
    mask = cv2.inRange(frame, dico["lower"], dico["upper"])
    if dico["BROWN_USED"]:
        brown_mask = cv2.inRange(
            frame, dico["brown_lower"], dico["brown_upper"])
    if dico["COMPUTER_USED"]:
        output = cv2.bitwise_and(frame, frame, mask=mask)
        if dico["BROWN_USED"]:
            brown_output = cv2.bitwise_and(
                frame, frame, mask=brown_mask)
    # Find all pixels detected in the mask
    coords = cv2.findNonZero(mask)
    if dico["BROWN_USED"]:
        brown_coords = cv2.findNonZero(brown_mask)
    nb_center = 0
    # In case if nothing is detected
    color_detected = False
    if coords is not None:
        color_detected = True
        for coord in coords:
            nb_center += coord[0][0]
            if dico["COMPUTER_USED"]:
                output = cv2.circle(output, coord[0], radius=0,
                                    color=(0, 0, 255), thickness=-1)
        # print(nb_center/len(coords)/width - 0.5, ", speed = ", speed)

    else:
        coords = [0]
        # print("color not detected, speed = ", speed)

    # Mask and output for color to be followed
    if dico["BROWN_USED"]:
        brown_mask = cv2.inRange(
            frame, dico["brown_lower"], dico["brown_upper"])
        if dico["COMPUTER_USED"]:
            brown_output = cv2.bitwise_and(
                frame, frame, mask=brown_mask)

        brown_nb_left = 0
        brown_nb_center = 0
        brown_nb_right = 0
        if brown_coords is not None:
            for coord in brown_coords:
                # If the coordinate is in the first (left) third
                if coord_is_in_left(coord[0], dico["width"]):
                    # Show the coordinate as red
                    if dico["COMPUTER_USED"]:
                        output = cv2.circle(output, coord[0], radius=0,
                                            color=(255, 255, 255), thickness=-1)
                    # Add the pixel to the left counter
                    brown_nb_left += 1
                elif coord_is_in_center(coord[0], dico["width"]):
                    if dico["COMPUTER_USED"]:
                        output = cv2.circle(output, coord[0], radius=0,
                                            color=(255, 255, 255), thickness=-1)
                    brown_nb_center += 1
                elif coord_is_in_right(coord[0], dico["width"]):
                    if dico["COMPUTER_USED"]:
                        output = cv2.circle(output, coord[0], radius=0,
                                            color=(255, 255, 255), thickness=-1)
                    brown_nb_right += 1
        else:
            brown_coords = [0]
        brown_center_percentage = brown_nb_center/len(brown_coords)
        if not dico["switch_ready"] and dico["brown_center_percentage"] < 0.2:
            dico["switch_ready"] = True
        if dico["switch_ready"] and 0.7 <= dico["brown_center_percentage"] and dico["brown_center_percentage"] <= 1:
            dico["lower"], dico["upper"] = dico["boundaries"][next_color(
                dico["current_color"], dico["boundaries"], dico["color_string"])]
            lower = np.array(dico["lower"], dtype="uint8")
            upper = np.array(dico["upper"], dtype="uint8")
            switch_ready = False

    if dico["COMPUTER_USED"]:
        # Visual line, not necessary for computing
        cv2.rectangle(output, (int(dico["width"]/3), dico["bot_band"]),
                      (int(dico["width"]*2/3), dico["top_band"]), (255, 0,  0), 2)

        # cv2.rectangle(output, (int(width/2)-5, 0),
        #              (int(width/2)+5, height), (0, 255, 0), 2)

        # Showing images
        cv2.imshow("images", np.hstack([frame, output]))

    if cv2.waitKey(1) & 0xFE == ord("n"):
        dico["lower"], dico["upper"] = dico["boundaries"][next_color(
            dico["current_color"], dico["boundaries"], dico["color_string"])]
        dico["lower"] = np.array(dico["lower"], dtype="uint8")
        dico["upper"] = np.array(dico["upper"], dtype="uint8")

    return ((nb_center/len(coords)), color_detected)
